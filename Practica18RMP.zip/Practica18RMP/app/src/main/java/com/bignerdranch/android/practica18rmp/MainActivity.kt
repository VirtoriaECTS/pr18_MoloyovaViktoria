package com.bignerdranch.android.practica18rmp


import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    private lateinit var login: EditText
    private lateinit var password: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



    }

    fun perehod(view: View) {
        login = findViewById(R.id.loginText)
        password = findViewById(R.id.passwordText)
        if (login.text.toString().isEmpty() || password.text.toString().isEmpty()){
            val i = Toast.makeText(this, "Введите логин и пароль", Toast.LENGTH_SHORT)
            i.setGravity(Gravity.TOP, 0, 160)
            i.show()

        }
        else{
            val intent = Intent(this, AddActivity::class.java)
            startActivity(intent)
        }

    }
}