package com.bignerdranch.android.practica18rmp

data class Ticket(val number: String, val type: String)
